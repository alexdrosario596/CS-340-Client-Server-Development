#!/usr/bin/env python
# coding: utf-8


from pymongo import MongoClient
import urllib.parse # Add import for urllib.parse

class CRUD:
    """ CRUD operations for MongoDB """

    def __init__(self, username, password, host, port, database_name, collection_name):
        
        self.client = MongoClient(f'mongodb://{urllib.parse.quote_plus(username)}:{urllib.parse.quote_plus(password)}@{host}:{port}')
        self.db = self.client[database_name]
        self.collection = self.db[collection_name]

    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise ValueError("Nothing to save because data parameter is empty")

    def read(self, query):
        try:
            result = list(self.collection.find(query))
            return result if result else []
        except Exception as e:
            print(f"An error occurred: {e}")
            return []
        
    def update(self, query, new_values):
        if query and new_values:
            try:
                update_result = self.collection.update_many(query, {"$set": new_values})
                return update_result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            raise ValueError("Both query and new values parameters are required for updating")
        
        
    def delete(self, query):
        if query:
            try:
                delete_result = self.collection.delete_many(query)
                return delete_result.deleted_count > 0
            except Exception as e:
                print(f"An error occurred during deletion: {e}")
                return False
        else:
            raise ValueError("Query parameter is required for deletion")

# Replace the placeholder values with your actual MongoDB credentials and collection details
username = 'aacuser'
password = 'Hukoz84!'
host = 'nv-desktop-services.apporto.com'
port = 30897  # MongoDB port
database_name = 'AAC'  # Your MongoDB database name
collection_name = 'animals'  # Your collection name within the database

# Create an instance of the CRUD class
crud = CRUD(username, password, host, port, database_name, collection_name)

# Example data to be inserted
sample_data = {
    "name": "Fluffy",
    "species": "Cat",
    "age": 3,
    "breed": "Siamese",
    "color": "White"
}

# Insert data into MongoDB
insert_status = crud.create(sample_data)
print(f"Insertion status: {insert_status}")

# Query data from MongoDB
query = {"species": "Cat"}
result = crud.read(query)
print("Query result count:", result)

#Update example:
update_query = {"species": "Cat"}
new_values = {"age": 4}
update_status = crud.update(update_query, new_values)
print(f"Update status: {update_status}")

#Delete example:
delete_query = {"species": "Cat"}
delete_status = crud.delete(delete_query)
print(f"Deletion status: {delete_status}")




